var rule = {
    模板: '首图',
    title: '樱花动漫[漫]',
    host: 'https://katedm.com/',
    url: '/list/fyclass-fypage.html',
    searchUrl: '/search/**----------fypage---.html',
    搜索: '#searchList li;a&&title;.lazyload&&data-original;.pic-tag&&Text;a&&href',
}